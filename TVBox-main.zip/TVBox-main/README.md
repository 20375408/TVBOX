## 本接口不再支持TVBox，请各位安装OK影视，功能更多，设计更合理，并且有手机端！

### [OK影视下载地址](https://2hacc.lanzoue.com/b00pzypv9g) 密码:5d5i
  
注：有些电视可能安装不成功，可以用海信版试试，可能有惊喜

## GitHub加速

### 国内访问访问地址一

```
https://cdn.jsdelivr.net/gh/2hacc/TVBox@main/oktv.json
```
### 国内访问访问地址二

```
https://raw.githubusercontents.com/2hacc/TVBox/main/oktv.json
```
### 国内访问访问地址三

```
https://raw.kkgithub.com/2hacc/TVBox/main/oktv.json
```
### 国内访问访问地址四
```
https://gitdl.cn/https://raw.githubusercontent.com/2hacc/TVBox/main/oktv.json
```
### 国内访问访问地址五
```
https://fastly.jsdelivr.net/gh/2hacc/TVBox@main/oktv.json
```
### 国内访问访问地址六
```
https://jsdelivr.pai233.top/gh/2hacc/TVBox@main/oktv.json
```
### 国内访问访问地址七
```
https://ghp.ci/https://raw.githubusercontent.com/2hacc/TVBox/main/oktv.json
```
### 国内访问访问地址八
```
https://raw.incept.pw/2hacc/TVBox/main/oktv.json
```